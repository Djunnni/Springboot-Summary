package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// 한번씩 Controller와 RestController 중 무엇을 사용해야될 지 고민하는 사람이 있다.
// RestController는 rest api 방식으로 코드를 짤 때, 사용하기 위해 만든 컨트롤러다.
// 그 외에는 Controller를 이용하자.
@Controller
public class MainController{

    // {name}은 {}에는 아무 내용이 들어올 수 있는데 이를 변수로 가져올 수 있다.
    // 가져오기 위해서 @PathVariable String name을 사용하였다.
    @GetMapping("/{name}.html")
    public String page(@PathVariable String name,Model model){
        model.addAttribute("pageName",name);
        return "page";
    }
}