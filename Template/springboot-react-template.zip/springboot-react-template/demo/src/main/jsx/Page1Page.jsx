// custom.css 파일 import
import '../webapp/css/custom.css';

import React from 'react';
import ReactDom from 'react-dom';

class Page1Page extends React.Component {
    render(){
        return <div className="page1">demo page1페이지</div>;
    }
}
ReactDom.render(<Page1Page/>,document.getElementById('root'));